import time
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User

@receiver(post_save, sender=User)
def post_save_user_handler(sender, instance, created, **kwargs):
    print("Signal received. Processing started...")
    time.sleep(5)  # Simulate a long-running task
    print("Signal processing completed after 5 seconds.")
